(document).ready(function(){
  $("#username").keyup(function(){
  var username=$("#username").val();
  username=username.trim();
 if(username=="")
{
setErrorMsg('username_class','Username cannot be empty');
}
else {
setSuccessMsg('username_class');
}
            
 
  });
});
