<?php
      session_start();
      $_SESSION["user_username"]=$_POST['username'];
      echo "started";  
?>
