function check_user{
username=$("#username").val();
username=username.trim();
password=$("#password").val();
password=password.trim();
    $jQuery.ajax({
		url:"check_user.php",
		data:{username:username,password:password},
		type:"POST",
		success:function(data)
		{
         return data;
          }

}); 
}

