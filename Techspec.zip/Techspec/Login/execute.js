const username=document.getElementById('username');
const password=document.getElementById('password');
function home() {
         window.location.href="/TechSpec/Home/Home.html";  
}
function setsession(username){
	jQuery.ajax({
		url:"session.php",
		data:{username:username},
		type:"POST",
		success:function(data)
		{
			console.log(data);
		},
		error:function(){
}
}); 
}
function check_user(username,password){
    $.ajax({
		url:"check_user.php",
		data:{username:username,password:password},
		type:"POST",
		success:function(data)
		{
         if(data!=0)
         {
         	setsession(username);
             openPopupSuccess();
         	}
         else{
         	openPopupErrorFailed();
         	}
          }
          
}); 
}
function check(){
const username=window.username.value.trim();
const password=window.password.value.trim();
const flag=0;
 if(username=="")
{
openPopupErrorFailed();
}
else if(password=="")
{
openPopupErrorFailed();
}
else
{
   check_user(username,password);
}
}


function openPopupSuccess(){
document.getElementById("username").setAttribute("disabled", "disabled");
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
disable.classList.add("disabled");
disable1.classList.add("disabled");
popup_success.classList.add("open-popup-success"); 
}
function closePopupSuccess(){
document.getElementById("username").removeAttribute("disabled");
document.getElementById("password").removeAttribute("disabled", "disabled");
document.getElementById("submit").removeAttribute("disabled", "disabled");
disable.classList.remove("disabled");
disable1.classList.remove("disabled");
popup_success.classList.remove("open-popup-success");
}
function openPopupError(){
document.getElementById("username").setAttribute("disabled", "disabled");
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
disable.classList.add("disabled");
disable1.classList.add("disabled");
popup_error.classList.add("open-popup-error"); 
}
function closePopupError(){
document.getElementById("username").removeAttribute("disabled");
document.getElementById("password").removeAttribute("disabled", "disabled");
document.getElementById("submit").removeAttribute("disabled", "disabled");
disable.classList.remove("disabled");
disable1.classList.remove("disabled");
popup_error.classList.remove("open-popup-error");
}
function openPopupErrorFailed(){
document.getElementById("username").setAttribute("disabled", "disabled");
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
disable.classList.add("disabled");
disable1.classList.add("disabled");
popup_error_failed.classList.add("open-popup-error-failed"); 
}
function closePopupErrorFailed(){
document.getElementById("username").removeAttribute("disabled");
document.getElementById("password").removeAttribute("disabled", "disabled");
document.getElementById("submit").removeAttribute("disabled", "disabled");
disable.classList.remove("disabled");
disable1.classList.remove("disabled");
popup_error_failed.classList.remove("open-popup-error-failed");
}

