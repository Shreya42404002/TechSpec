<?php
	    include 'C:\xampp\htdocs\Techspec\Config\Config.php';
	    $password=md5($_POST['password']);
		$query ="SELECT * FROM  `registration` WHERE username='".$_POST['username']."' AND pass_word='$password'";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);
		$data=mysqli_error($conn);
		echo $count;
		
?>
