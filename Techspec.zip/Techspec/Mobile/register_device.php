<?php    
$id=$_POST['id'];
$name=$_POST['name'];
$image=$_POST['image'];
$ram=$_POST['ram'];
$rom=$_POST['rom'];
$price=$_POST['price'];
$battery=$_POST['battery'];
$front_camera=$_POST['front_camera'];
$back_camera=$_POST['back_camera'];
$amazon_price=$_POST['amazon_price'];
$amazon_link=$_POST['amazon_link'];
$flipkart_price=$_POST['flipkart_price'];
$flipkart_link=$_POST['flipkart_link'];
$chroma_price=$_POST['chroma_price'];
$chroma_link=$_POST['chroma_link'];
$conn=mysqli_connect("localhost","root","","project");
$query ="INSERT INTO `mobile_data` (`Sr_No`, `id`, `name`, `image`, `ram`, `rom`, `price`, `battery`, `front_camera`, `back_camera`, `amazon_price`, `amazon_link`, `flipkart_price`, `flipkart_link`, `chroma_price`, `chroma_link`) VALUES (NULL, '$id', '$name', '$image', '$ram', '$rom', '$price', '$battery', '$front_camera', '$back_camera', '$amazon_price', '$amazon_link', '$flipkart_price', '$flipkart_link', '$chroma_price', '$chroma_link')";
mysqli_query($conn,$query);
echo mysqli_error($conn);
?>
