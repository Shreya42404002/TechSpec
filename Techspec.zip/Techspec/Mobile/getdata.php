<?php
$price_flag=$_POST['price'];
$battery_flag=$_POST['battery'];
$ram_flag=$_POST['ram'];
$rom_flag=$_POST['rom'];
$front_camera_flag=$_POST['front_camera'];
$back_camera_flag=$_POST['back_camera'];
$query1="";
$file=fopen("Report.txt","w++");


	include 'C:\xampp\htdocs\Techspec\Config\Config.php';
	if($ram_flag==0)
	{
	}
	else
    {
    	$query1="WHERE ram=".$ram_flag."";
	}
	if($rom_flag==0)
	{
	}
	else
    {
    	if($query1=="")
        {
        	$query1="WHERE rom=".$rom_flag."";
        }
        else {
        $query2="AND rom=".$rom_flag."";
    	$query1=$query1." ".$query2;
         }
	}
	if($price_flag==0)
	{
		
	}
	else if($price_flag==1)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 10000 AND 19999";
        }
        else{
		$query2=" AND price BETWEEN 10000 AND 19999";
		$query1=$query1." ".$query2;
		}
	}
	else if($price_flag==2)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 20000 AND 29999";
        }
        else{
		$query2=" AND price BETWEEN 20000 AND 29999";
		$query1=$query1." ".$query2;
		}
		
	}
	else if($price_flag==3)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 30000 AND 39999";
        }
        else{
		$query2=" AND price BETWEEN 30000 AND 39999";
		$query1=$query1." ".$query2;
		}
		
	}
	else if($price_flag==4)
	{
		if($query1=="")
        {
        	$query1="WHERE price BETWEEN 40000 AND 49999";
        }
        else{
		$query2="AND price BETWEEN 40000 AND 49999";
		$query1=$query1." ".$query2;
		}
		
	}
	else if($price_flag==5)
	{
		if($query1=="")
        {
        	$query1="WHERE price >=50000";
        }
        else{
		$query2=" AND price >=50000";
		$query1=$query1." ".$query2;
		}
		
	}
	 if($battery_flag==0)
	{
		
	}
	else
    {
    	if($query1=="")
        {
        	$query1="WHERE battery=".$battery_flag."";
        }
        else{
		$query2=" AND battery=".$battery_flag."";
		$query1=$query1." ".$query2;
		}
    	
	}
	if($front_camera_flag==0)
	{
		
	}
	else
    {
    	if($query1=="")
        {
        	$query1="WHERE front_camera=".$front_camera_flag."";
        }
        else{
		$query2=" AND front_camera=".$front_camera_flag."";
		$query1=$query1." ".$query2;
		}
    	
	}
	if($back_camera_flag==0)
	{
		
	}
	else
    {
    	if($query1=="")
        {
        	$query1="WHERE back_camera=".$back_camera_flag."";
        }
        else{
		$query2=" AND back_camera=".$back_camera_flag."";
		$query1=$query1." ".$query2;
		}
	}
	
       $query="SELECT * FROM `mobile_data` ".$query1;
       
       $query_run = mysqli_query($conn, $query);
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
$id=$device['id'];
$name=$device['name'];
$image=$device['image'];
$ram=$device['ram'];
$rom=$device['rom'];
$price=$device['price'];
$battery=$device['battery'];
$front_camera=$device['front_camera'];
$back_camera=$device['back_camera'];
$amazon_price=$device['amazon_price'];
$amazon_link=$device['amazon_link'];
$flipkart_price=$device['flipkart_price'];
$flipkart_link=$device['flipkart_link'];
$chroma_price=$device['chroma_price'];
$chroma_link=$device['chroma_link'];
echo '<div class="result" id="result"><img id="mobile_image" src=" ' .$image. ' "></img><div  class="info" id="info"><div id="product_title"><h3 id="mobile_title">' .$name. '</h3></div><p>Price:-  &#8377<span>' .$price. '</span></p><p id="amazon">Amazon Price:-  <a id="amazon_link" href=" ' .$amazon_link. ' "><span id="amazon_price">&#8377 ' .$amazon_price. '</span></a></p><p id="flipkart">Flipkart Price:- <a id="flipkart_link" href=" ' .$flipkart_link. ' "><span id="flipkart_price">&#8377 ' .$flipkart_price. '</span></a></p><p id="chroma">Chroma Price:- <a id="chroma_link" href="'.$chroma_link.'"><span id="chroma_price">&#8377  ' .$chroma_price. '</span></a></p></div></div>';
fwrite($file,"NAME : ".$name."");
fwrite($file,"\nRAM : ".$ram."");
fwrite($file,"\nROM : ".$rom."");
fwrite($file,"\nPRICE : ".$price."");
fwrite($file,"\nBATTERY : ".$battery."");
fwrite($file,"\nFRONT_CAMERA : ".$front_camera."");
fwrite($file,"\nBACK_CAMERA : ".$back_camera."");
fwrite($file,"\nAMAZON PRICE : ".$amazon_price."");
fwrite($file,"\nAMAZON LINK : ".$amazon_link."");
fwrite($file,"\nFLIPKART PRICE : ".$flipkart_price."");
fwrite($file,"\nFLIPKART LINK : ".$flipkart_link."");
fwrite($file,"\nCHROMA PRICE : ".$chroma_price."");
fwrite($file,"\nCHROMA LINK : ".$chroma_link."");
fwrite($file,"\n----------------------------------------------------------------------");
fwrite($file,"\n----------------------------------------------------------------------\n");
}
 }
                                    else
                                    {
                                        echo "";
                                    }      
    fclose($file);

?>