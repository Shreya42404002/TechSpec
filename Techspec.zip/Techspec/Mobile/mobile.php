<!doctype html>
<html>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
var price=0;
var battery=0;
var ram=0;
var rom=0;
var front_camera=0;
var back_camera=0;
function clearall()
{
document.getElementById("price").value=0;
document.getElementById("battery").value=0;
document.getElementById("ram").value=0;
document.getElementById("storage").value=0;
document.getElementById("front_camera").value=0;
document.getElementById("back_camera").value=0;
var a=" ";
document.getElementById('container').innerHTML =a+'<?php show(); ?>';
}
function sendReport()
{
var price=window.price;
var battery=window.battery;
var ram=window.ram;
var rom=window.rom;
var front_camera=window.front_camera;
var back_camera=window.back_camera;
if(price==0&&battery==0&&ram==0&&rom==0&&front_camera==0&&back_camera==0)
{
  alert("Please Apply Filters To Get The Report");
}
else {
	sendEmail();
  alert("Report Send");
	}
}
function sendEmail(){
	jQuery.ajax({
		url:"report_mail.php",
		type:"POST",
		success:function(data)
		{
      console.log(data);
      console.log("hhhedw");

		},
		error:function(){		
}
}); 
}
function apply()
{
var price=document.getElementById("price").value;
var battery=document.getElementById("battery").value;
var ram=document.getElementById("ram").value;
var rom=document.getElementById("storage").value;
var front_camera=document.getElementById("front_camera").value;
var back_camera=document.getElementById("back_camera").value;
window.price=price;
window.battery=battery;
window.ram=ram;
window.rom=rom;
window.front_camera=front_camera;
window.back_camera=back_camera;
showdata(price,battery,ram,rom,front_camera,back_camera);
}
	function showdata(price,battery,ram,rom,front_camera,back_camera){
	jQuery.ajax({
		url:"getdata.php",
		data:{price:price,battery:battery,ram:ram,rom:rom,front_camera:front_camera,back_camera:back_camera},
		type:"POST",
		success:function(data)
		{
			$('#container').html(data);
		},
		error:function(){
}
}); 
}
</script>
  <title>Mobile</title>
		<body>			
		<div class="box" >
		<br><br>
      <h1 align ="center" style="color:#8711A9">Select Specification</h1>
	  <br>
	  <hr></hr>
<br>
	<label style = "color: #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Price &nbsp</label> 
		<select id="price"  style="font-size:20px;">
            <option value="0">Select</option>
            <option value="1">Rs. 10000 - Rs.19999</option>
            <option value="2">Rs. 20000 - Rs. 29999</option>
            <option value="3">Rs. 30000 - Rs. 39999</option>
            <option value="4">Rs. 40000 - Rs. 49999</option>
            <option value="5">Rs. 50000 and above</option>
		</select>
<br>
<br>
		<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Storage &nbsp</label> 
		<select id="storage"  style="font-size:20px;">
			<option value="0">Select</option>
            <option value="1">8GB</option>
            <option value="2">16GB</option>
            <option value="3">32GB</option>
            <option value="4">64GB</option>
            <option value="5">128GB</option>
            <option value="6">256GB and above</option>
		</select>
	<br>
    <br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Front Camera &nbsp</label> 
		<select id="front_camera"  style="font-size:20px;">
            <option value="0">Select</option>
            <option value="1">Below 5 MP</option>
            <option value="2">5 - 7.9 MP</option>
            <option value="3">8 - 11.9 MP</option>
            <option value="4">12 - 15.9 MP</option>
            <option value="5">16 - 20.9 MP</option>
            <option value="6">21 MP and above</option>
		</select>
<br>
<br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp                     Back Camera &nbsp</label> 
    <select id="back_camera" style="font-size:20px;">
            <option value="0" >Select</option>
            <option value="1">Below 5 MP </option>
            <option value="2">8 - 11.9 MP</option>
            <option value="3">12 - 20.9 MP</option>
            <option value="4">21 - 47.9 MP</option>
            <option value="5">48 - 63.9 MP</option>
            <option value="6">64 MP and above</option>
		</select>
<br>
<br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp RAM &nbsp</label> 
		<select id="ram"  style="font-size:20px;">
            <option value="0" >Select</option>
            <option value="1">2GB</option>
            <option value="2">3GB</option>
            <option value="3">4GB</option>
            <option value="4">6GB</option>
            <option value="5">8GB and above</option>
		</select>
<br>
<br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Battery &nbsp</label> 
		<select id="battery"  style="font-size:20px;">
             <option value="0">Select</option>
             <option value="1">1000-1999 mAh</option>
            <option value="2">2000-2999 mAh</option>
            <option value="3">3000-3999 mAh</option>
            <option value="4">4000-4999 mAh</option>
            <option value="5">5000 and above</option>
		</select>
<br>
<br>
<br>
<br>
<br>
<br>
<button id="apply" name="apply" onclick="apply()">Apply</button>
<button id="clear" name="apply" onclick="clearall()">Clear</button>
<button id="report" name="apply" onclick="sendReport()">Get Report</button>
    <div class="container" id="container" name="container">
    	<?php
$conn=mysqli_connect("localhost","root","","project");
$query="SELECT * FROM `mobile_data` ";
$query_run = mysqli_query($conn, $query);
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
$id=$device['id'];
$name=$device['name'];
$image=$device['image'];
$ram=$device['ram'];
$rom=$device['rom'];
$price=$device['price'];
$battery=$device['battery'];
$front_camera=$device['front_camera'];
$back_camera=$device['back_camera'];
$amazon_price=$device['amazon_price'];
$amazon_link=$device['amazon_link'];
$flipkart_price=$device['flipkart_price'];
$flipkart_link=$device['flipkart_link'];
$chroma_price=$device['chroma_price'];
$chroma_link=$device['chroma_link'];
echo '<div class="result" id="result"><img id="mobile_image" src=" ' .$image. ' "></img><div  class="info" id="info"><div id="product_title"><h3 id="mobile_title">' .$name. '</h3></div><p>Price:-  &#8377<span>' .$price. '</span></p><p id="amazon">Amazon Price:-  <a id="amazon_link" href=" ' .$amazon_link. ' "><span id="amazon_price">&#8377 ' .$amazon_price. '</span></a></p><p id="flipkart">Flipkart Price:- <a id="flipkart_link" href=" ' .$flipkart_link. ' "><span id="flipkart_price">&#8377 ' .$flipkart_price. '</span></a></p><p id="chroma">Chroma Price:- <a id="chroma_link" href="'.$chroma_link.'"><span id="chroma_price">&#8377  ' .$chroma_price. '</span></a></p></div></div>';
                                                          }
 }
                                    else
                                    {
                                        echo "";
                                    }      
                                    
?>
    </div>
	</div>
</body>
</html>

<style>
#profile{
	height:100px;
	width:100px;
	margin-left:50px;
	}
#wishlist{
	width:50px;
	height:50px;
	position: absolute;
	top:30%;
	right:-30%;
	}
.container{
	height:620px;
	width:650px;
	border:1px solid skyblue;
	background-color: white;
	position: absolute;
	top:0%;
	right:-110%;
	overflow-y: scroll;
  padding: 10px;
	}
.info{
	position:absolute;
	height:50px;
	width:300px;
	top:10%;
	right:20%;
	}
#mobile_image{
  height:100%;
  width:30%;
  margin-top: 2px;
  margin-bottom: 2px;
  margin-right: 2px;
  margin-left: 2px;
}
.result{
  position:relative;
	height:40%;
	width:96%;
	border-radius:10px;
	border:4px solid skyblue;
	background-color: white;
  margin-top: 10px;
  margin-bottom: 10px;
  margin-right: 10px;
  margin-left: 10px;
	/*background-color: rgba(255,255,255,0.13);*/
	}

img{
	
	width:1500px;
	height:250px;
	position:relative;
	}

body{
  background-color: #080710;
}

/*Box */
.box{
	position: relative;
	height:620px;
	width:650px;
	border:1px solid skyblue;
	padding:10px;
	margin:20px;
	background-color: white;
	backdrop-filter:blur(100px)
}
/*the container must be positioned relative:*/


.select-selected {
  background-color: #ff7f50;
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
}

/*style items (options):*/
.select-items {
  position: absolute;
  background-color: purple;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}


.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}

.drop{
	background-color: #ffcc00;
}

/*Select Box */
/*the container must be positioned relative:*/
.custom-select {
  position: relative;
  font-family: Arial;
  height:40px;
}


.select-selected {
  background-color:#8711a9;
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
}

/*style items (options):*/
.select-items {
  position: absolute;
  background-color: #808080;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}

/*hide the items when the select box is closed:*/
.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}

p.text{
	text-align:left;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

#apply{
  padding: 8px 15px;
  position: absolute;
  left: 10%;
}

#clear{
  padding: 8px 15px;
  position: absolute;
  left: 40%;
}

#report{
  padding: 8px 15px;
  position: absolute;
  left: 70%;
}
</style>
<?php
function show()
{
$conn=mysqli_connect("localhost","root","","project");
$query="SELECT * FROM `mobile_data` ";
$query_run = mysqli_query($conn, $query);
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
$id=$device['id'];
$name=$device['name'];
$image=$device['image'];
$ram=$device['ram'];
$rom=$device['rom'];
$price=$device['price'];
$battery=$device['battery'];
$front_camera=$device['front_camera'];
$back_camera=$device['back_camera'];
$amazon_price=$device['amazon_price'];
$amazon_link=$device['amazon_link'];
$flipkart_price=$device['flipkart_price'];
$flipkart_link=$device['flipkart_link'];
$chroma_price=$device['chroma_price'];
$chroma_link=$device['chroma_link'];
echo '<div class="result" id="result"><img id="mobile_image" src=" ' .$image. ' "></img><div  class="info" id="info"><div id="product_title"><h3 id="mobile_title">' .$name. '</h3></div><p>Price:-  &#8377<span>' .$price. '</span></p><p id="amazon">Amazon Price:-  <a id="amazon_link" href=" ' .$amazon_link. ' "><span id="amazon_price">&#8377 ' .$amazon_price. '</span></a></p><p id="flipkart">Flipkart Price:- <a id="flipkart_link" href=" ' .$flipkart_link. ' "><span id="flipkart_price">&#8377 ' .$flipkart_price. '</span></a></p><p id="chroma">Chroma Price:- <a id="chroma_link" href="'.$chroma_link.'"><span id="chroma_price">&#8377  ' .$chroma_price. '</span></a></p></div></div>';
                                                          }
 }
                                    else
                                    {
                                        echo "";
                                    }      
                                    }
?>
