-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 03, 2022 at 05:39 AM
-- Server version: 5.7.34
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `laptop_data`
--

CREATE TABLE `laptop_data` (
  `id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `ram` varchar(500) NOT NULL,
  `storage` varchar(500) NOT NULL,
  `price` int(11) NOT NULL,
  `processor` varchar(500) NOT NULL,
  `operating_system` varchar(500) NOT NULL,
  `amazon_price` varchar(100) NOT NULL,
  `amazon_link` varchar(500) NOT NULL,
  `flipkart_price` varchar(100) NOT NULL,
  `flipkart_link` varchar(500) NOT NULL,
  `chroma_price` varchar(100) NOT NULL,
  `chroma_link` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `laptop_data`
--

INSERT INTO `laptop_data` (`id`, `name`, `image`, `ram`, `storage`, `price`, `processor`, `operating_system`, `amazon_price`, `amazon_link`, `flipkart_price`, `flipkart_link`, `chroma_price`, `chroma_link`) VALUES
('ZTo1Nzc2NzQ', 'HP 15-BS542TU (2EY84PA) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81Nzc2NzQtMTc0LTE.jpg', '4 GB  Memory', '1 TB  HDD', 32961, 'Intel Core i3  Processor', 'DOS ', 'Not available', 'https://www.amazon.in', 'Not available', 'https://www.flipkart.com', 'Not available', 'https://www.croma.com/?utm_source=google&utm_medium=ps&utm_campaign=sok_search_brand_acq-purebrand&gclid=Cj0KCQjw852XBhC6ARIsAJsFPN0cpwLb4VskTG6TQ4kNPq1OmNlnsJ2jnMId1VYp2XY9D42hwnmIJvwaAnHpEALw_wcB'),
('ZTo1ODY4MTQ', 'HP Pavilion Gaming 15-ec1025AX (183J8PA) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81ODY4MTQtMjkzLTE.jpg', '8 GB  Memory', '512 GB SSD', 57990, 'AMD Hexa-Core Ryzen 5  Processor', 'Windows 10 Home Basic', 'Not available', 'https://www.amazon.in', '69990', 'https://price-api.datayuge.com/redirect?id=aHR0cHM6Ly9kbC5mbGlwa2FydC5jb20vZGwvaHAtcGF2aWxpb24tcnl6ZW4tNS1oZXhhLWNvcmUtOC1nYi01MTItZ2Itc3NkLXdpbmRvd3MtMTAtaG9tZS00LWdyYXBoaWNzLW52aWRpYS1nZWZvcmNlLWd0eC0xNjUwdGktMTQ0LWh6LTE1LWVjMTAyNWF4LWdhbWluZy1sYXB0b3AvcC9pdG01MGZlMTUwYWVjZDg2P3BpZD1DT01HM0ZIQlNERVIyQUhLJmFmZmlkPWFydW5iYWJ1bA', '57990', 'https://www.croma.com/hp-pavilion-15-ec1025ax-ryzen-5-windows-10-home-gaming-laptop-8gb-ram-512gb-ssd-nvidia-geforce-gtx-1650ti-+-4gb-gddr6-39-62cm-183j8pa-acj-shadow-black-/p/248778'),
('ZTo1OTI0MDk', 'Dell Vostro 14 3400 (D552201WIN9DE) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81OTI0MDktMTMtMQ.jpg', '8 GB  Memory', '256 GB SSD', 32990, 'Intel Core i3 (11th Gen)  Processor', 'Windows 10 Home Basic', '43000', 'https://price-api.datayuge.com/redirect?id=aHR0cHM6Ly93d3cuYW1hem9uLmluL2dwL29mZmVyLWxpc3RpbmcvQjA5RjNRWkxCNi8_JnRhZz1wcmljZXl1Z2UwZC0yMQ', 'Not available', 'https://www.flipkart.com', '32990', 'https://www.croma.com/dell-vostro-3400-11th-gen-core-i3-windows-10-home-thin-and-light-8gb-ram-256gb-ssd-intel-uhd-graphics-ms-office-2019-35-56cm-d552201win9de-dune-/p/245024'),
('ZTo0NDI0NjQ', 'Simmtronics 2GB DDR3 1600Mhz Laptop Ram', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC80NDI0NjQtOS0x.jpg', 'DDR 3', '', 1999, '2 GB Memory', 'Windows 10 Home Basic', 'Not available', 'https://www.amazon.in', 'Not available', 'https://www.flipkart.com', 'Not available', 'https://www.croma.com/?utm_source=google&utm_medium=ps&utm_campaign=sok_search_brand_acq-purebrand&gclid=Cj0KCQjw852XBhC6ARIsAJsFPN0cpwLb4VskTG6TQ4kNPq1OmNlnsJ2jnMId1VYp2XY9D42hwnmIJvwaAnHpEALw_wcB'),
('ZTo1NzYyNjM', 'HP 15q-ds0029tu (6DT09PA) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81NzYyNjMtMTg4LTE.jpg', '8 GB  Memory', '1 TB  HDD', 51930, 'Intel Core i5  Processor', 'Windows 10 Home Basic', 'Not available', 'https://www.amazon.in', 'Not available', 'https://www.flipkart.com', 'Not available', 'https://www.croma.com/?utm_source=google&utm_medium=ps&utm_campaign=sok_search_brand_acq-purebrand&gclid=Cj0KCQjw852XBhC6ARIsAJsFPN0cpwLb4VskTG6TQ4kNPq1OmNlnsJ2jnMId1VYp2XY9D42hwnmIJvwaAnHpEALw_wcB'),
('ZTo1OTQzMzI', 'HP 15s-dy3501TU (5S7P8PA) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81OTQzMzItMTM1LTE.jpg', '8 GB  Memory', '512 GB SSD', 43950, 'Intel Core i3 (11th Gen)  Processor', 'Windows 11 Home Basic', '43950', 'https://price-api.datayuge.com/redirect?id=aHR0cHM6Ly93d3cuYW1hem9uLmluL2dwL29mZmVyLWxpc3RpbmcvQjA5UDFQWUdYNS8_JnRhZz1wcmljZXl1Z2UwZC0yMQ', 'Not available', 'https://www.flipkart.com', 'Not available', 'https://www.croma.com/?utm_source=google&utm_medium=ps&utm_campaign=sok_search_brand_acq-purebrand&gclid=Cj0KCQjw852XBhC6ARIsAJsFPN0cpwLb4VskTG6TQ4kNPq1OmNlnsJ2jnMId1VYp2XY9D42hwnmIJvwaAnHpEALw_wcB'),
('ZTo1NzU5NjA', 'HP 14q-cs0017tu (7EF82PA) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81NzU5NjAtOTYtMQ.jpg', '8 GB  Memory', '1 TB  HDD', 53554, 'Intel Core i5 (8th Gen)  Processor', 'Windows 10 Home Basic', 'Not available', 'https://www.amazon.in', 'Not available', 'https://www.flipkart.com', 'Not available', 'https://www.croma.com/?utm_source=google&utm_medium=ps&utm_campaign=sok_search_brand_acq-purebrand&gclid=Cj0KCQjw852XBhC6ARIsAJsFPN0cpwLb4VskTG6TQ4kNPq1OmNlnsJ2jnMId1VYp2XY9D42hwnmIJvwaAnHpEALw_wcB'),
('ZTo1NzYwMzY', 'HP Pavilion TouchSmart 14 x360 14-dh0107tu (7AL87PA) Laptop', 'https://images-api.datayuge.in/image/dHI6dy0xNDAwLGgtMTQwMCxjLWF0X21heC81NzU5NjAtOTYtMQ.jpg', '8 GB  Memory', '1 TB  HDD', 53554, 'Intel Core i5 (8th Gen)  Processor', 'Windows 10 Home Basic', 'Not available', 'https://www.amazon.in', 'Not available', 'https://www.flipkart.com', 'Not available', 'https://www.croma.com/?utm_source=google&utm_medium=ps&utm_campaign=sok_search_brand_acq-purebrand&gclid=Cj0KCQjw852XBhC6ARIsAJsFPN0cpwLb4VskTG6TQ4kNPq1OmNlnsJ2jnMId1VYp2XY9D42hwnmIJvwaAnHpEALw_wcB');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `laptop_data`
--
ALTER TABLE `laptop_data`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
