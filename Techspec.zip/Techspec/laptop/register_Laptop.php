<?php    
$id=$_POST['id'];
$name=$_POST['name'];
$image=$_POST['image'];
$ram=$_POST['ram'];
$storage=$_POST['storage'];
$price=$_POST['price'];
$processor =$_POST['processor'];
$operating_system=$_POST['operating_system'];
$amazon_price=$_POST['amazon_price'];
$amazon_link=$_POST['amazon_link'];
$flipkart_price=$_POST['flipkart_price'];
$flipkart_link=$_POST['flipkart_link'];
$chroma_price=$_POST['chroma_price'];
$chroma_link=$_POST['chroma_link'];
$conn=mysqli_connect("localhost","root","","project");
$query ="INSERT INTO `laptop_data` (`id`, `name`, `image`, `ram`, `storage`, `price`, `processor`, `operating_system`, `amazon_price`, `amazon_link`, `flipkart_price`, `flipkart_link`, `chroma_price`, `chroma_link`) VALUES  ('$id', '$name', '$image', '$ram', '$storage', '$price', '$processor', '$operating_system', '$amazon_price', '$amazon_link', '$flipkart_price', '$flipkart_link', '$chroma_price', '$chroma_link')";
mysqli_query($conn,$query);
echo mysqli_error($conn);
echo "success";
?>
