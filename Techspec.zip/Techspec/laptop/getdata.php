<?php
$price_flag=$_POST['price'];
$ram_flag=$_POST['ram'];
$storage_flag=$_POST['storage'];
$operating_system_flag=$_POST['operating_system'];
$processor_flag=$_POST['processor'];
$query1="";
$file=fopen("Report.txt","a");

	   $conn=mysqli_connect("localhost","root","","project");
	if($ram_flag==0)
	{
	}
	else
    {
    	$query1=" WHERE ram LIKE '%".$ram_flag."%'";
	}
	if($price_flag==0)
	{
		
	}
	else if($price_flag==1)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 10000 AND 29999";
        }
        else{
		$query2=" AND price BETWEEN 10000 AND 29999";
		$query1=$query1." ".$query2;
		}
	}
	else if($price_flag==2)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 30000 AND 49999";
        }
        else{
		$query2=" AND price BETWEEN 30000 AND 49999";
		$query1=$query1." ".$query2;
		}
		
	}
	else if($price_flag==3)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 50000 AND 69999";
        }
        else{
		$query2=" AND price BETWEEN 50000 AND 69999";
		$query1=$query1." ".$query2;
		}
		
	}
	else if($price_flag==4)
	{
		if($query1=="")
        {
        	$query1=" WHERE price BETWEEN 70000 AND 99999 ";
        }
        else{
		$query2=" AND price BETWEEN 70000 AND 99999";
		$query1=$query1." ".$query2;
		}
		
	}
	else if($price_flag==5)
	{
		if($query1=="")
        {
        	$query1=" WHERE price >=100000";
        }
        else{
		$query2=" AND price >=100000";
		$query1=$query1." ".$query2;
		}
		
	}
	 if($storage_flag==0)
	{
		
	}
	else
    {
    	if($query1=="")
        {
        	$query1=" WHERE storage LIKE '%".$storage_flag."%'";
        }
        else{
		$query2=" AND storage LIKE  '%".$storage_flag."%'";
		$query1=$query1." ".$query2;
		}
    	
	}
	if($operating_system_flag==0)
	{
		
	}
	else
    {
    	if($query1=="")
        {
        	$query1=" WHERE operating_system LIKE '%".$operating_system_flag."%'";
        }
        else{
		$query2=" AND operating_system LIKE '%".$operating_system_flag."%'";
		$query1=$query1." ".$query2;
		}
    	
	}
	if($processor_flag==0)
	{
		
	}
	else
    {
    	if($query1=="")
        {
        	$query1=" WHERE processor LIKE '%".$processor_flag."%'";
        }
        else{
		$query2=" AND processor LIKE '%".$processor_flag."%'";
		$query1=$query1." ".$query2;
		}
	}
	
       $query="SELECT * FROM `laptop_data` ".$query1;
       
       $query_run = mysqli_query($conn, $query);
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
$id=$device['id'];
$name=$device['name'];
$image=$device['image'];
$ram=$device['ram'];
$storage=$device['storage'];
$price=$device['price'];
$processor =$device['processor'];
$operating_system=$device['operating_system'];
$amazon_price=$device['amazon_price'];
$amazon_link=$device['amazon_link'];
$flipkart_price=$device['flipkart_price'];
$flipkart_link=$device['flipkart_link'];
$chroma_price=$device['chroma_price'];
$chroma_link=$device['chroma_link'];
echo '<div class="result" id="result"><img id="mobile_image" src=" ' .$image. ' "></img><div  class="info" id="info"><div id="product_title"><h3 id="mobile_title">' .$name. '</h3></div><p>Price:-  &#8377<span>' .$price. '</span></p><p id="amazon">Amazon Price:-  <a id="amazon_link" href=" ' .$amazon_link. ' "><span id="amazon_price">&#8377 ' .$amazon_price. '</span></a></p><p id="flipkart">Flipkart Price:- <a id="flipkart_link" href=" ' .$flipkart_link. ' "><span id="flipkart_price">&#8377 ' .$flipkart_price. '</span></a></p><p id="chroma">Chroma Price:- <a id="chroma_link" href="'.$chroma_link.'"><span id="chroma_price">&#8377  ' .$chroma_price. '</span></a></p></div></div>';
fwrite($file,"NAME : ".$name."");
fwrite($file,"\nRAM : ".$ram."");
fwrite($file,"\nSTORAGE : ".$storage."");
fwrite($file,"\nPRICE : ".$price."");
fwrite($file,"\nOPERATING SYSTEM : ".$operating_system."");
fwrite($file,"\nPROCESSOR : ".$processor."");
fwrite($file,"\nAMAZON PRICE : ".$amazon_price."");
fwrite($file,"\nAMAZON LINK : ".$amazon_link."");
fwrite($file,"\nFLIPKART PRICE : ".$flipkart_price."");
fwrite($file,"\nFLIPKART LINK : ".$flipkart_link."");
fwrite($file,"\nCHROMA PRICE : ".$chroma_price."");
fwrite($file,"\nCHROMA LINK : ".$chroma_link."");
fwrite($file,"\n----------------------------------------------------------------------");
fwrite($file,"\n----------------------------------------------------------------------\n");

                                                          }
 }
                                    else
                                    {
                                        echo "";
                                    }      
fclose($file);
                                    
?>