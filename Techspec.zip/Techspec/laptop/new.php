<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
(async () =>{
async function getResponse()
{
	var settings = {
		"async": true,
		"crossDomain": true,
		"url": "https://price-api.datayuge.com/api/v1/compare/search?api_key=ufJdmP5EKk88fHIhKKcNGXnuvxDFyt2aTA3&product=laptop&page=3",
		"method": "GET"
	}
	return $.ajax(settings).done(function(response) {
		return response;
		});
}
var response=await getResponse();
console.log(response["data"].length);
console.log(response);
})();
</script>