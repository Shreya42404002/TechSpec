<!doctype html>
<html>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
var price=0;
var storage=0;
var ram=0;
var operating_system=0;
var processor=0;
function clearall()
{
document.getElementById("price").value=0;
document.getElementById("processor").value=0;
document.getElementById("ram").value=0;
document.getElementById("storage").value=0;
document.getElementById("operating_system").value=0;
var a=" ";
document.getElementById('container').innerHTML =a+'<?php show(); ?>';

}
function sendReport()
{
var price=window.price;
var storage=window.storage;
var ram=window.ram;
var operating_system=window.operating_system;
var processor=window.processor;
if(price==0&&storage==0&&ram==0&&operating_system==0&&processor==0)
{
	alert("Please Apply Filters To Get The Report");
}
else {
	sendEmail();
  alert("Report Send");
	}
}
function sendEmail(){
	jQuery.ajax({
		url:"report_mail.php",
		type:"POST",
		success:function(data)
		{
		},
		error:function(){		
}
}); 
}
function apply()
{
var price=document.getElementById("price").value;
var storage=document.getElementById("storage").value;
var ram=document.getElementById("ram").value;
var operating_system=document.getElementById("operating_system").value;
var processor=document.getElementById("processor").value;
window.price=price;
window.storage=storage;
window.ram=ram;
window.operating_system=operating_system;
window.processor=processor;
showdata(price,ram,storage,operating_system,processor);
}
	function showdata(price,ram,storage,operating_system,processor){
	jQuery.ajax({
		url:"getdata.php",
		data:{price:price,ram:ram,storage:storage,operating_system:operating_system,processor:processor},
		type:"POST",
		success:function(data)
		{
			$('#container').html(data);
		},
		error:function(){
}
}); 
}
</script>
  <title>Laptop</title>
		<body>			
		<div class="box" >
		<br><br>
      <h1 align ="center" style="color:#8711A9">Select Specification</h1>
	  <br>
	  <hr></hr>
<br>
	<label style = "color: #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Price &nbsp</label> 
		<select id="price"  style="font-size:20px;">
            <option value="0">Select</option>
            <option value="1">Rs. 10000 - Rs.29999</option>
            <option value="2">Rs. 30000 - Rs. 49999</option>
            <option value="3">Rs. 50000 - Rs. 69999</option>
            <option value="4">Rs. 70000 - Rs. 99999</option>
            <option value="5">Rs. 100000 and above</option>
		</select>
<br>
<br>
		<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Operating System &nbsp</label> 
		<select id="operating_system"  style="font-size:20px;">
			<option value="0">Select</option>
            <option value="Windows 8">Windows 8</option>
            <option value="Windows 10">Windows 10</option>
            <option value="Windows 11">Windows 11</option>
            <option value="Mac OS">Mac OS</option>
            <option value="DOS">DOS</option>
            <option value="Chrome">Chrome</option>
		</select>
	<br>
    <br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Storage Capacity &nbsp</label> 
		<select id="storage"  style="font-size:20px;">
            <option value="0">Select</option>
            <option value="128 GB SSD">128 GB SSD</option>
            <option value="256 GB SSD">256 GB SSD</option>
            <option value="512 GB SSD">512 GB SSD</option>
            <option value="1 TB SSD">1 TB SSD</option>
            <option value="2 TB SSD">2 TB SSD</option>
            <option value="256 GB HDD">256 GB HDD</option>
            <option value="512 HDD">512 GB HDD</option>
            <option value="1 TB HDD">1 TB HDD</option>
            <option value="2 TB HDD">2 TB HDD</option>
		</select>
<br>
<br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp RAM Capacity &nbsp</label> 
		<select id="ram"  style="font-size:20px;">
            <option value="0" >Select</option>
            <option value="2 GB">2GB</option>
            <option value="4 GB">4GB</option>
            <option value="8 GB">8GB</option>
            <option value="12 GB">12GB</option>
            <option value="16 GB">16GB</option>
            <option value="32 GB">32GB</option>
		</select>
<br>
<br>
	<label style = "color:  #493bb3; font-size:25px;">&nbsp&nbsp&nbsp Processor  &nbsp</label> 
		<select id="processor"  style="font-size:20px;">
             <option value="0">Select</option>
             <option value="Core i3 "> Core i3 Processor</option>
            <option value="Core i5"> Core i5 Processor</option>
            <option value="Core i7"> Core i7 Processor</option>
            <option value="Core i9"> Core i9 Processor</option>
            <option value="Ryzen 3"> Ryzen 3 Processor</option>
            <option value="Ryzen 5"> Ryzen 5 Processor</option>
            <option value="Ryzen 7"> Ryzen 7 Processor</option>
            <option value="Ryzen 9"> Ryzen 9 Processor</option>
            <option value="M1"> M1 Processor</option>
            <option value="M2"> M2 Processor</option>
            <option value="AMD">AMD  Processor</option>
            <option value="Celeron">Intel Celeron Processor</option>
		</select>
<br>
<br>
<br>
<br>
<br>
<br>
<button id="apply" name="apply" onclick="apply()">Apply</button>
<button id="clear" name="apply" onclick="clearall()">Clear</button>
<button id="report" name="apply" onclick="sendReport()">Get Report</button>
    <div class="container" id="container" name="container">
    	<?php
$query="SELECT * FROM `laptop_data` ";
$query_run = mysqli_query($conn, $query);
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
$id=$device['id'];
$name=$device['name'];
$image=$device['image'];
$ram=$device['ram'];
$storage=$device['storage'];
$price=$device['price'];
$processor =$device['processor'];
$operating_system=$device['operating_system'];
$amazon_price=$device['amazon_price'];
$amazon_link=$device['amazon_link'];
$flipkart_price=$device['flipkart_price'];
$flipkart_link=$device['flipkart_link'];
$chroma_price=$device['chroma_price'];
$chroma_link=$device['chroma_link'];
echo '<div class="result" id="result"><img id="mobile_image" src=" ' .$image. ' "></img><div  class="info" id="info"><div id="product_title"><h3 id="mobile_title">' .$name. '</h3></div><p>Price:-  &#8377<span>' .$price. '</span></p><p id="amazon">Amazon Price:-  <a id="amazon_link" href=" ' .$amazon_link. ' "><span id="amazon_price">&#8377 ' .$amazon_price. '</span></a></p><p id="flipkart">Flipkart Price:- <a id="flipkart_link" href=" ' .$flipkart_link. ' "><span id="flipkart_price">&#8377 ' .$flipkart_price. '</span></a></p><p id="chroma">Chroma Price:- <a id="chroma_link" href="'.$chroma_link.'"><span id="chroma_price">&#8377  ' .$chroma_price. '</span></a></p></div></div>';
                                                          }
 }
                                    else
                                    {
                                        echo "";
                                    }      
?>
    </div>
	</div>
</body>
</html>

<style>
.container{
	height:620px;
	width:650px;
	border:1px solid skyblue;
	background-color: white;
	position: absolute;
	top:0%;
	right:-110%;
	overflow-y: scroll;
  padding: 10px;
	}
.info{
	position:absolute;
	height:50px;
	width:300px;
	top:10%;
	right:20%;
	}
#mobile_image{
  height:100%;
  width:30%;
  margin-top: 2px;
  margin-bottom: 2px;
  margin-right: 2px;
  margin-left: 2px;
}
.result{
  position:relative;
	height:40%;
	width:96%;
	border-radius:10px;
	border:4px solid skyblue;
	background-color: white;
  margin-top: 10px;
  margin-bottom: 10px;
  margin-right: 10px;
  margin-left: 10px;
	/*background-color: rgba(255,255,255,0.13);*/
	}


body{
  background-color: #080710;
}

/*Box */
.box{
	position: relative;
	height:620px;
	width:650px;
	border:1px solid skyblue;
	padding:10px;
	margin:20px;
	background-color: white;
	backdrop-filter:blur(100px)
}
/*the container must be positioned relative:*/


.select-selected {
  background-color: #ff7f50;
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
}

/*style items (options):*/
.select-items {
  position: absolute;
  background-color: purple;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}


.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}

.drop{
	background-color: #ffcc00;
}

/*Select Box */
/*the container must be positioned relative:*/
.custom-select {
  position: relative;
  font-family: Arial;
  height:40px;
}


.select-selected {
  background-color:#8711a9;
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div,.select-selected {
  color: #ffffff;
  padding: 8px 16px;
  border: 1px solid transparent;
  border-color: transparent transparent rgba(0, 0, 0, 0.1) transparent;
  cursor: pointer;
  user-select: none;
}

/*style items (options):*/
.select-items {
  position: absolute;
  background-color: #808080;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 99;
}

/*hide the items when the select box is closed:*/
.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}

p.text{
	text-align:left;
}
#apply{
  padding: 8px 15px;
  position: absolute;
  left: 10%;
}

#clear{
  padding: 8px 15px;
  position: absolute;
  left: 40%;
}

#report{
  padding: 8px 15px;
  position: absolute;
  left: 70%;
}
</style>
<?php
function show()
{
$conn=mysqli_connect("localhost","root","","project");
$query="SELECT * FROM `laptop_data` ";
$query_run = mysqli_query($conn, $query);
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
$id=$device['id'];
$name=$device['name'];
$image=$device['image'];
$ram=$device['ram'];
$storage=$device['storage'];
$price=$device['price'];
$processor =$device['processor'];
$operating_system=$device['operating_system'];
$amazon_price=$device['amazon_price'];
$amazon_link=$device['amazon_link'];
$flipkart_price=$device['flipkart_price'];
$flipkart_link=$device['flipkart_link'];
$chroma_price=$device['chroma_price'];
$chroma_link=$device['chroma_link'];
echo '<div class="result" id="result"><img id="mobile_image" src=" ' .$image. ' "></img><div  class="info" id="info"><div id="product_title"><h3 id="mobile_title">' .$name. '</h3></div><p>Price:-  &#8377<span>' .$price. '</span></p><p id="amazon">Amazon Price:-  <a id="amazon_link" href=" ' .$amazon_link. ' "><span id="amazon_price">&#8377 ' .$amazon_price. '</span></a></p><p id="flipkart">Flipkart Price:- <a id="flipkart_link" href=" ' .$flipkart_link. ' "><span id="flipkart_price">&#8377 ' .$flipkart_price. '</span></a></p><p id="chroma">Chroma Price:- <a id="chroma_link" href="'.$chroma_link.'"><span id="chroma_price">&#8377  ' .$chroma_price. '</span></a></p></div></div>';
                                                          }
 }
                                    else
                                    {
                                        echo "";
                                    }      
                                    }
?>
