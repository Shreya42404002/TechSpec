<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Administrator</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" integrity="sha512-PgQMlq+nqFLV4ylk1gwUOgm6CtIIXkKwaIHp/PAIWHzig/lKZSEGKEysh0TCVbHJXCLN7WetD8TFecIky75ZfQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="mobile_view_data.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="delete_mobile.js"></script>
</head>
<body>
		<h1 align="center">AVAILABLE MOBILE</h1>
		<div class="divScroll">
			
		<table>
			
			<tr>
				<th>SR.NO</th>
				<th>ID</th>
				<th>NAME</th>
				<th>IMAGE URL</th>
				<th>RAM</th>
				<th>ROM</th>
				<th>PRICE</th>
				<th>BATTERY</th>
				<th>FRONT CAMERA</th>
				<th>BACK CAMERA</th>
				<th>AMAZON PRICE</th>
				<th>AMAZON LINK</th>
				<th>FLIPKART PRICE</th>
				<th>FLIPKART LINK</th>
				<th>CHROMA PRICE</th>
				<th>CHROMA LINK</th>
				<th>ACTION</th>
			</tr>
			<?php
                    include("Config.php");
					$query = "SELECT * FROM `mobile_data`";
					$query_run = mysqli_query($conn, $query);
					$sr_no=0;
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $device)
                                        {
                                        	$sr_no=$sr_no+1;
               ?>	
                                            <tr>
<td><?= $sr_no; ?></td>
<td><?= $device['id']; ?></td>
<td><?= $device['name']; ?></td>
<td><?= $device['image']; ?></td>
<td><?= $device['ram']; ?></td>
<td><?= $device['rom']; ?></td>
<td><?= $device['price']; ?></td>
<td><?= $device['battery']; ?></td>
<td><?= $device['front_camera']; ?></td>
<td><?= $device['back_camera']; ?></td>
<td><?= $device['amazon_price']; ?></td>
<td><?= $device['amazon_link']; ?></td>
<td><?= $device['flipkart_price']; ?></td>
<td><?= $device['flipkart_link']; ?></td>
<td><?= $device['chroma_price']; ?></td>
<td><?= $device['chroma_link']; ?></td>
                                                <td>
                                                    <div class="d-inline">
                                                        <button name="delete_mobile" id="<?=$device['id'];?>" class="delete_user" onclick="delete_user(this.id)" >Delete</button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
			?>
				
		</table>
		
		</div>
</body>
<div class="popup_success" id="popup_success">
            <img src="tick.png">
           <h2 id="h2text"></h2>
           <button type="button" id="ok" onclick="document.location.reload(true)">OK</button>
</div>
<div class="popup_edit" id="popup_edit">
           <h2>Update User Details</h2>
           <div class="form-control" id="username_class">
        <label for="username">Username: </label>   
     <input type="text" placeholder="Username" id="username" name="username">
        <i class="fas fa check-circle" id="circle" name="circle"></i> <i class="fas fa-check-circle fa-2x" id="circle"></i>
         <i class="fas fa exclamation-circle" id="circle" name="circle"></i> <i class="fas fa-exclamation-circle fa-2x" id="circle"></i>
         <br>
<small id="username_class_small" >Error message</small>
</div>
<div class="form-control" id="email_class">
        <label for="email">Email: </label>
        <input type="text" placeholder="Email" id="email" name="email">
        <i class="fas fa check-circle" id="circle" name="circle"></i> <i class="fas fa-check-circle fa-2x" id="circle"></i>
         <i class="fas fa exclamation-circle" id="circle" name="circle"></i> <i class="fas fa-exclamation-circle fa-2x" id="circle"></i>
         <br>
<small id="email_class_small">Error message</small>
</div>
	
            <button type="button" id="yes" onclick="update_user()">Update</button>
           <button type="button" id="no" onclick="closePopupEdit()">X</button>
</div>
<div class="popup_error" id="popup_error">
           <h2>Do you really want to delete user?</h2>
            <button type="button" id="yes1" onclick="closePopup()">Yes</button>
           <button type="button" id="no1" onclick="closePopupError()">No</button>
        </div>
</html>
