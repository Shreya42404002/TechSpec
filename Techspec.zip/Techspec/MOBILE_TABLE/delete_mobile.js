var id=0;
function delete_user(id)
{
	console.log(id);
	window.id=id;
	console.log(window.id);
	openPopupError();
}

function closePopupSuccess(){
popup_success.classList.remove("open-popup-success");
}
function openPopupSuccess(){
popup_success.classList.add("open-popup-success"); 
}
function openPopupError(){
popup_error.classList.add("open-popup-error"); 
}
function closePopupError(){
popup_error.classList.remove("open-popup-error");
}
function closePopup(){
console.log("hjjjjj");
var id = window.id;
 $.ajax({
		url:"delete_mobile.php",
		data:{id:id},
		type:"POST",
		success:function(data)
		{
			closePopupError();
			console.log(data);
			document.getElementById("h2text").innerHTML="User Deleted Successfully";
			openPopupSuccess();
         }
}); 
popup_error.classList.remove("open-popup-error");
}



























