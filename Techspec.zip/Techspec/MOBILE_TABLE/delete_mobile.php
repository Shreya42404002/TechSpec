<?php
    $id= $_POST['id'];
    include("Config.php");
    $query = "DELETE FROM `mobile_data` WHERE id='".$id."'";
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
    	return 1;
    }
    else
    {
        return 0;
    }
?>
