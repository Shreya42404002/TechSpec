function check(){
  var email=document.getElementById('email');
  email=email.value.trim();
 if(email=="")
{
	document.getElementById("p1").innerHTML = "Email cannot be blank";
	openPopupErrorFailed();
}else if(!isEmail(email))
{
	document.getElementById("p1").innerHTML = "Not a Valid Email";
	openPopupErrorFailed();
}
else{
    $.ajax({
		url:"check_email.php",
		data:{email:email},
		type:"POST",
		success:function(data)
		{
		console.log(data);
         if(data!=0){
         window.location.href="/TechSpec/Verify_OTP/Verify_otp.html";  
            }
            else{
            	document.getElementById("p1").innerHTML = "Email is not registered";	
               openPopupErrorFailed();
            }
}
}); 
}
}
function isEmail(email){
	var atSymbol=email.indexOf("@");
	var dot=email.lastIndexOf('.');
	if(atSymbol<1) {
           return false;
     }else if(dot<(atSymbol+3)) {
           return false;
     }else if(dot== email.length-1) {
          return false;
     }else{
	      return true;
}
}
function openPopupErrorFailed(){
popup_error_failed.classList.add("open-popup-error-failed"); 
topnav.classList.add("disabled");
navbar.classList.add("disabled");
}
function closePopupErrorFailed(){
popup_error_failed.classList.remove("open-popup-error-failed");
topnav.classList.remove("disabled");
navbar.classList.remove("disabled");
}

