<?php
$verification_code=rand(100000,999999);
$to_email =$_POST['email'];
$Email="techspec.tk@gmail.com";
$subject = "Verification OTP";
$body = "We have received a request to reset your password.
Your OTP  is ".$verification_code.".
Incase this request did not come from you, change your account password immediately to prevent further unauthorized access and you can also contact us at techspec.tk@gmail.com.
We are grateful for your cooperation,
TechSpec Team";
$headers = "From: $Email";
	   $conn=mysqli_connect("localhost","root","","project");
		$query ="SELECT * FROM  `registration` WHERE email='" . $_POST['email'] . "' ";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);
		if($count==0)
		{
			}
			else{
				session_start();
				session_id('verification_code_email');
				$_SESSION['verification_code']=$verification_code;
                $_SESSION['email']=$to_email;
				mail($to_email, $subject, $body, $headers);
				}
		echo $count;
?>
