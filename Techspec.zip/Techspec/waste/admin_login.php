<?php
	$conn=mysqli_connect("localhost","root","","project");
	$USERNAME=($_POST['username']);
	$PASSWORD=($_POST['password']);


		$query="SELECT * FROM  `administrator` WHERE USERNAME='$USERNAME' AND PASS_WORD='$PASSWORD'";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);
		echo $count;
		if($count == 1) {
            
		    header("location: admin_view_data.php");
		 }else {
            header("location: admin_login.html");
		 }    
?>