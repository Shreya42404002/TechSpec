
<?php

$mysqli = new mysqli("localhost", "root","","project");
$sql = " SELECT * FROM register";
$result = $mysqli->query($sql);
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Administrator</title>
	<style>
		table {
			
			margin: 0 auto;
			font-size: large;
			border: 2px solid black;
		}

		h1 {
			text-align: center;
			color: #8711A9;
			font-size: xx-large;
			font-family: 'Gill Sans', 'Gill Sans MT',
			' Calibri', 'Trebuchet MS', 'sans-serif';
		}

		th,
		td {
			background-color: #E4F5D4;
			font-weight: bold;
			border: 1px solid black;
			padding: 10px;
			text-align: center;
		}

		td {
			font-weight: lighter;
		}

		/* Header and Footer*/
		#headline{
    color: #f2f2f2;
    position: fixed;
    top: 16px;
    right: 40px;
    font-size: 30px;
    font-style: bold;
}

/* Add a black background color to the top navigation */
.topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ffffff;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #8711A9;
  color: white;
}

body{
    background-color: #080710;
}

/*Footer*/

/* Place the navbar at the bottom of the page, and make it stick */
.navbar {
  background-color: #333;
  overflow: hidden;
  position: fixed;
  bottom: 0;
  width: 100%;
}

/* Style the links inside the navigation bar */
.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

	</style>
</head>

<body>
	<section>
	<!-- Header-->
	<div class="topnav">
        <a class="active" href="homepage.html">Home</a>
        <a href="privacypolicy.html">Privacy Policy</a>
        <a href="contactus.html">Contact Us</a>
        <a href="aboutus.html">About Us</a>
        &nbsp;
        <label ID="headline">TECHSPEC</label>
      </div>

	<!-- Footer-->
	  <div class="navbar">
		<a href="#home" class="active">Home</a>
		<a href="#admin_login">Admin Login</a>
		<a href="#emailverify">Change Password</a>
		<a href="#support">Support</a>
	  </div>

		<h1 align="center">REGISTERD USERS</h1>
		
		<table>
			<tr>
				<th>EMAIL</th>
				<th>USERNAME</th>
				<th>PASSWORD</th>
			
			</tr>
			
			<?php
			
					$mysqli = new mysqli("localhost", "root","","project");
					$sql = " SELECT * FROM `registration`";
					$result = $mysqli->query($sql);
					$mysqli->close();
				while($rows=$result->fetch_assoc())
				{

					echo "<tr><td>" .$rows['email']."</td><td>".$rows['Username']."</td><td>".($rows['Pass_word'])."</td></tr>";
				}
			?>
		</table>
	</section>
</body>

</html>
