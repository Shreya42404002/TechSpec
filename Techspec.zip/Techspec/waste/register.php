<?php
   
   $conn=mysqli_connect("localhost","root","","project");
$EMAIL=$_POST['email'];
$USERNAME=$_POST['username'];
$PASSWORD=md5($_POST['password']);
$SQL="INSERT INTO `registration` (`email`,`Username`,`Pass_word`) VALUE ('$EMAIL','$USERNAME','$PASSWORD')";
mysqli_query($conn,$SQL) ;

?>