<?php
session_start();
if((isset($_SESSION['admin_username']))||(isset($_SESSION['user_username'])))
{

}

else

{
    header("Location: /Techspec/Login/Login.html");
    exit();
}
?>
<!doctype html>
<html>
<script>
  function openNav() {
  document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
  <title>User Dashboard</title>
		<body>			
      <img src="banner.png">
		<br><br>
      <div class="logout"><a href="logout.php">Logout<img  id="logout" src="logout.png"></a></div>
      <div id="mySidenav" class="sidenav">
      <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
      <div>
      <img id="profile" src="profile.png"></img>
      <br>
      	<?php
session_start();

if(isset($_SESSION['admin_username']))
{
	echo "<p id='username' >".$_SESSION['admin_username']."<p>";
}
else if(isset($_SESSION['user_username']))
{
	echo "<p id='username'>".$_SESSION['user_username']."<p>";
}
else{
	echo "<p id='username' >Not Logged in<p>";
	}
?>
      	
      	</div>
      <br>
      <br>
      <br>
      <br>
      <a href="/Techspec/Mobile/mobile.php" target="frame" onclick="closeNav()">Mobile Compare</a>
      <br>
      <a href="/Techspec/laptop/laptop.php" target="frame" onclick="closeNav()">Laptop Compare</a>
      <br>
      <a href="/Techspec/PC/PC.php" target="frame" onclick="closeNav()">PC Setup</a>
      <br>
      <a href="/Techspec/CPU/CPU.php" target="frame" onclick="closeNav()">CPU Building</a>
      <br>
      <br>
    </div>
    <span style="font-size:25px;cursor:pointer;color:#493bb3;" onclick="openNav()">&nbsp &#9776;&nbsp Menu</span>
    <iframe id="frame" name="frame" class="frame" src="/Techspec/Mobile/mobile.php"></iframe>
</body>
</html>

<style>
.logout{
	position: absolute;
	top:245px;
	right:-490px;
	font-size:30px;
	}
.logout a{
	color: red;
	text-decoration: none;
	}
.logout img{
	height:50px;
	width:50px;
	top:16px;
	right:-10px;
}
.frame{
	height:700px;
	width:1500px;
	}
img{
	width:1500px;
	height:250px;
	position:relative;
	}
#profile{
	height:100px;
	width:100px;
	margin-left:100px;
	}
#username{
	font-size: 25px;
	color: #FFFFFF;
	text-align:center
	}
p.text{
	text-align:left;
}

.sidenav {
  height:640px;
  width: 0;
  margin-top:316px;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #FFFFFF;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}


</style>