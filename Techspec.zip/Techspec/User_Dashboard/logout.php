<?php
session_start();
if(session_destroy()){
header("Location: /Techspec/Home/Home.html");
}
else{
	echo "error";
	}
?>