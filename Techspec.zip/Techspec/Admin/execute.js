const username=document.getElementById('username');
const password=document.getElementById('password');
function home() {
         window.location.href="/TechSpec/Home/Home.html";  
}
function setsession(username){
	jQuery.ajax({
		url:"session.php",
		data:{username:username},
		type:"POST",
		success:function(data)
		{
			console.log(data);
		},
		error:function(){
}
}); 
}
function check_admin(username,password){
    $.ajax({
		url:"check_admin.php",
		data:{username:username,password:password},
		type:"POST",
		success:function(data)
		{
         if(data!=0)
         {
         	setsession(username);
            window.location.href="user_view_data.php";  
      	}
         else{
         	openPopupErrorFailed();
         	}
          }
          
}); 
}
function check(){
const username=window.username.value.trim();
const password=window.password.value.trim();
const flag=0;
 if(username=="")
{
openPopupErrorFailed();
}
else if(password=="")
{
openPopupErrorFailed();
}
else
{
   check_admin(username,password);
}
}

function openPopupErrorFailed(){
document.getElementById("username").setAttribute("disabled", "disabled");
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
popup_error_failed.classList.add("open-popup-error-failed"); 
}
function closePopupErrorFailed(){
document.getElementById("username").removeAttribute("disabled");
document.getElementById("password").removeAttribute("disabled", "disabled");
document.getElementById("submit").removeAttribute("disabled", "disabled");
popup_error_failed.classList.remove("open-popup-error-failed");
}

