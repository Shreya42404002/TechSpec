<?php
      session_start();
      $_SESSION["admin_username"]=$_POST['username'];
      echo "started";  
?>
