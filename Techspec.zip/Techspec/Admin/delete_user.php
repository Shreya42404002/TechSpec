<?php
    $username= $_POST['username'];
    include 'C:\xampp\htdocs\Techspec\Config\Config.php';
    $query = "DELETE FROM registration WHERE username='$username' ";
    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
    	return 1;
    }
    else
    {
        return 0;
    }
?>
