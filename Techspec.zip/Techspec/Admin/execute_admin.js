const username=document.getElementById('username');
const email=document.getElementById('email');
const username1="null";
const username_id="null";
const username_default="null";
const email_default="null";
function delete_user(username2)
{
	console.log(username2);
	window.username1=username2;
	console.log(window.username1);
	openPopupError();
}


function edit_user(username,email)
{
	console.log(username+email);
	document.getElementById('username').value=username;
	window.username_id=username;
	window.username_default=username;
	window.email_default=email;
	console.log(window.username_id);
	document.getElementById('email').value=email;
	openPopupEdit();
}
function returnEmail()
{
	return window.email_default;
	}
function returnUsername()
{
	return window.username_default;
	}
function isEmail(email){
	var atSymbol=email.indexOf("@");
	var dot=email.lastIndexOf('.');
	if(atSymbol<1) {
           return false;
     }else if(dot<(atSymbol+3)) {
           return false;
     }else if(dot== email.length-1) {
          return false;
     }else{
	      return true;
}
}
function update_user()
{
console.log("tjtrjjr");
if(email=="")
{
	setErrorMsg('email_class','Email cannot be blank');
}
 if(username=="")
{
setErrorMsg('username_class','Username cannot be empty');
}
if(successMsg()==2)
{
	const username=document.getElementById('username').value;
    const email=document.getElementById('email').value;
    console.log(username);
    console.log(email);
	update(email,username,window.username_id);
	removeSuccessMsg('username_class');
	removeSuccessMsg('email_class');
	document.getElementById("h2text").innerText="USER UPDATED SUCCESSFULLY";
	openPopupSuccess();
}
}
function setErrorMsg(input,errormsg)
{
	const formControl = document.getElementById(input).className;
	const name="#"+input+"_small";
	const small = document.querySelector(name);
	document.getElementById(input).className="form-control error";
	small.innerText=errormsg;
}

function update(email,username,username_id){
	jQuery.ajax({
		url:"update_to_database.php",
		data:{email:email,username:username, username_id:username_id},
		type:"POST",
		success:function(data)
		{
			console.log(data);
			closePopupEdit();
			
		},
		error:function(){
}
}); 
}
function setSuccessMsg(input)
{
	document.getElementById(input).className="form-control success";
}
function removeSuccessMsg(input)
{
	document.getElementById(input).className="form-control disable";
}

function successMsg()
{
		let formCon=document.getElementsByClassName('form-control');
		var count=formCon.length-1;
		var sRate=0;
		for(var i=0;i<formCon.length;i++)
		{
			if(formCon[i].className==="form-control success")
            {
				sRate=sRate+1;
			}
			else {
					
					}
			}
			return sRate;
}
function closePopupSuccess(){
popup_success.classList.remove("open-popup-success");
}
function openPopupSuccess(){
popup_success.classList.add("open-popup-success"); 
}
function openPopupEdit(){
popup_edit.classList.add("open-popup-edit");

}
function closePopupEdit(){
popup_edit.classList.remove("open-popup-edit");
document.location.reload(true);
}
function openPopupError(){
popup_error.classList.add("open-popup-error"); 
}
function closePopupError(){
popup_error.classList.remove("open-popup-error");
}
function closePopup(){
console.log("hjjjjj");
var username = window.username1;
 $.ajax({
		url:"delete_user.php",
		data:{username:username},
		type:"POST",
		success:function(data)
		{
			closePopupError();
			console.log(data);
			document.getElementById("h2text").innerHTML="User Deleted Successfully";
			openPopupSuccess();
         }
}); 
popup_error.classList.remove("open-popup-error");
}



























