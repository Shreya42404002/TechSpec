<?php

session_start();
if(isset($_SESSION['admin_username']))
{
    
}
else
{
    header("Location: Admin_Login.html");//admin login page link
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Administrator</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" integrity="sha512-PgQMlq+nqFLV4ylk1gwUOgm6CtIIXkKwaIHp/PAIWHzig/lKZSEGKEysh0TCVbHJXCLN7WetD8TFecIky75ZfQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="style_admin.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="check_username.js"></script>
    <script src="check_email.js"></script>
	<script src="execute_admin.js"></script>
</head>
<body>
		<h1 align="center">REGISTERD USERS</h1>
		<div class="divScroll">
			
		<table>
			
			<tr>
				<th>SR.NO</th>
				<th>EMAIL</th>
				<th>USERNAME</th>
				<th>DATE</th>
				<th>TIME</th>
				<th>STATUS</th>
				<th>Action</th>
			</tr>
			<?php
					include 'C:\xampp\htdocs\Techspec\Config\Config.php';
					$query = " SELECT * FROM `registration`";
					$query_run = mysqli_query($conn, $query);
					$sr_no=0;
					if(mysqli_num_rows($query_run) > 0)
                                 {
                                        foreach($query_run as $user)
                                        {
                                        	$sr_no=$sr_no+1;
                                            ?>
                                            <tr>
                                            	<td><?= $sr_no?></td>
                                                <td><?= $user['email']; ?></td>
                                                <td><?= $user['username']; ?></td>
                                                <td><?= $user['date']; ?></td>
                                                <td><?= $user['time']; ?></td>
                                                <td><?= $user['status']; ?></td>
                                                <td>
                                                    <div class="d-inline">
                                                    	   <button name="<?= $user['email']; ?>" id="<?=$user['username'];?>" class="edit_user" onclick="edit_user(this.id,this.name)" >EDIT</button>
                                                        <button name="delete_user" id="<?=$user['username'];?>" class="delete_user" onclick="delete_user(this.id)" >Delete</button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
			?>
				
		</table>
		
		</div>
</body>
<div class="popup_success" id="popup_success">
            <img src="tick.png">
           <h2 id="h2text"></h2>
           <button type="button" id="ok" onclick="document.location.reload(true)">OK</button>
</div>
<div class="popup_edit" id="popup_edit">
           <h2>Update User Details</h2>
           <div class="form-control" id="username_class">
        <label for="username">Username: </label>   
     <input type="text" placeholder="Username" id="username" name="username">
        <i class="fas fa check-circle" id="circle" name="circle"></i> <i class="fas fa-check-circle fa-2x" id="circle"></i>
         <i class="fas fa exclamation-circle" id="circle" name="circle"></i> <i class="fas fa-exclamation-circle fa-2x" id="circle"></i>
         <br>
<small id="username_class_small" >Error message</small>
</div>
<div class="form-control" id="email_class">
        <label for="email">Email: </label>
        <input type="text" placeholder="Email" id="email" name="email">
        <i class="fas fa check-circle" id="circle" name="circle"></i> <i class="fas fa-check-circle fa-2x" id="circle"></i>
         <i class="fas fa exclamation-circle" id="circle" name="circle"></i> <i class="fas fa-exclamation-circle fa-2x" id="circle"></i>
         <br>
<small id="email_class_small">Error message</small>
</div>
	
            <button type="button" id="yes" onclick="update_user()">Update</button>
           <button type="button" id="no" onclick="closePopupEdit()">X</button>
</div>
<div class="popup_error" id="popup_error">
           <h2>Do you really want to delete user?</h2>
            <button type="button" id="yes1" onclick="closePopup()">Yes</button>
           <button type="button" id="no1" onclick="closePopupError()">No</button>
        </div>
</html>
