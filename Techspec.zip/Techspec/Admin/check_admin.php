<?php
	    include 'C:\xampp\htdocs\Techspec\Config\Config.php';
	    $username=($_POST['username']);
	    $password=($_POST['password']);
		$query="SELECT `username`, `pass_word` FROM `administrator` WHERE username='$username' AND pass_word='$password'";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);
		echo $count;
?>