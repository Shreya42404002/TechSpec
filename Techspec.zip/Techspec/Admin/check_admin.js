function check_user(){
username=$("#username").val();
username=username.trim();
password=$("#password").val();
password=password.trim();
    $jQuery.ajax({
		url:"check_admin.php",
		data:{username:username,password:password},
		type:"POST",
		success:function(data)
		{
			if(data!=0)
			{
				startsession();
				}
				else{
					openPopupErrorFailed()
					}
          }

}); 
}

