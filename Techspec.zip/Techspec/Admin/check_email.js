$(document).ready(function(){
  $("#email").keyup(function(){
  	var email=$("#email").val();
  email=email.trim();
  const email_default=returnEmail();
  console.log(email_default.localeCompare(email));
 if(email=="")
{
	setErrorMsg('email_class','Email cannot be blank');
}else if(!isEmail(email))
{
	setErrorMsg('email_class','Not a valid email');
}
else{
    $.ajax({
		url:"check_email.php",
		data:{email:email,email_default:email_default},
		type:"POST",
		success:function(data)
		{
         if(data!=0){
         setErrorMsg('email_class','Email is already registered');
            }
            else {
            setSuccessMsg('email_class');
            }
            }

}); 
}
  });
});
