<?php

      $email=$_POST['email'] ;
      $username=$_POST['username'];
      $username_id=$_POST['username_id'];
	  include 'C:\xampp\htdocs\Techspec\Config\Config.php';
		$query ="UPDATE `registration` SET `username`='$username' ,`email`='$email' WHERE `username`='$username_id'";
		if(mysqli_query($conn,$query)){
			echo $username_id;
			}
		else{
			echo "failed";
			}
?>
