$(document).ready(function(){
  $("#username").keyup(function(){
  	var username=$("#username").val();
  username=username.trim();
  const username_default=returnUsername();
 if(username=="")
{
setErrorMsg('username_class','Username cannot be empty');
}
else if(1>=username.length)
{
	setErrorMsg('username_class','Username cannot be less than 2 chars');
}
else
{ 
    $.ajax({
		url:"check_username.php",
		data:{username:username,username_default:username_default},
		type:"POST",
		success:function(data)
		{
         if(data!=0){
         setErrorMsg('username_class','Username is not available');
            }
            else {
            setSuccessMsg('username_class');
            
            }
            }

}); 
}

  });
});
