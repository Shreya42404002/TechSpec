
var invalid_otp=0;
function check(){
  var OTP=document.getElementById('OTP');
  OTP=OTP.value.trim();
 if(OTP=="")
{  
	document.getElementById("p1").innerHTML = "Please enter a code.";
	openPopupErrorFailed();
	document.getElementById('OTP').value="";
}else if(OTP.length<6)
{
	document.getElementById("p1").innerHTML = "You entered only "+OTP.length+" digits. Please check your code and try again.";
	openPopupErrorFailed();
	document.getElementById('OTP').value="";
}else if(OTP.length>6)
{
	document.getElementById("p1").innerHTML = "You entered more than 6 digits. Please check your code and try again.";
	openPopupErrorFailed();
	document.getElementById('OTP').value="";
}
else{
    $.ajax({
		url:"check_OTP.php",
		type:"POST",
		success:function(data)
		{
		console.log(data);
         if(data==OTP){
         	window.location.href="/TechSpec/Change_Password/Change_Password.html";
            }
            else{
           	document.getElementById("p1").innerHTML = "The number you entered does not match your code. Please try again.";	
               openPopupErrorFailed();
               document.getElementById('OTP').value="";
            }
}
}); 
}


}
function openPopupErrorFailed(){
popup_error_failed.classList.add("open-popup-error-failed"); 
topnav.classList.add("disabled");
navbar.classList.add("disabled");
}
function closePopupErrorFailed(id){
if(id==5)
{
		window.location.href="/TechSpec/Home/Home.html";
}
popup_error_failed.classList.remove("open-popup-error-failed");
topnav.classList.remove("disabled");
navbar.classList.remove("disabled");
}

