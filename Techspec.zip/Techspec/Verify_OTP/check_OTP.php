<?php
session_start();
echo $_SESSION['verification_code'];
?>