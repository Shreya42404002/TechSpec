const password=document.getElementById('password');
const cpassword=document.getElementById('cpassword');
function home() {
         window.location.href="/Home/Home.html";  
}
function insert(password){
	jQuery.ajax({
		url:"update_to_database.php",
		data:{password:password},
		type:"POST",
		success:function(data)
		{
			
		},
		error:function(){
}
}); 
}

function sendEmail(){
	jQuery.ajax({
		url:"password_change_mail.php",
		type:"POST",
		success:function(data)
		{
			
		},
		error:function(){
			
}
}); 
}
function check(){
const password=window.password.value.trim();
const cpassword=window.cpassword.value.trim();
if(password=="")
{
	setErrorMsg('password_class','Password cannot be blank');
	}
 if(cpassword=="")
{
	setErrorMsg('cpassword_class','Confirm Password cannot be blank');
	}


if(successMsg()==2)
{
	insert(password);
	sendEmail();
	openPopupSuccess();
	}
}
function setErrorMsg(input,errormsg)
{
	const formControl = document.getElementById(input).className;
	const name="#"+input+"_small";
	const small = document.querySelector(name);
	document.getElementById(input).className="form-control error";
	small.innerText=errormsg;
}
function setSuccessMsg(input)
{
	document.getElementById(input).className="form-control success";
}

function successMsg()
{
		let formCon=document.getElementsByClassName('form-control');
		var count=formCon.length-1;
		var sRate=0;
		for(var i=0;i<formCon.length;i++)
		{
			if(formCon[i].className==="form-control success")
            {
				sRate=sRate+1;
			}
			else {
					
					}
			}
			return sRate;
}
function openPopupSuccess(){
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("cpassword").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
popup_success.classList.add("open-popup-success"); 
}
function openPopupError(){
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("cpassword").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
popup_error.classList.add("open-popup-error"); 
}
function closePopupError(){
document.getElementById("password").removeAttribute("disabled", "disabled");
document.getElementById("cpassword").removeAttribute("disabled", "disabled");
document.getElementById("submit").removeAttribute("disabled", "disabled");
popup_error.classList.remove("open-popup-error");
}
