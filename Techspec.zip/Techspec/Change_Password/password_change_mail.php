<?php
session_start();
session_id('verification_code_email');
$to_email =$_SESSION['email'];
$Email="techspec.tk@gmail.com";
$subject = "Your password was changed";
$body = "The password for your TechSpec Account was changed. If you didn't change it, you should recover your account.";
$headers = "From: $Email";
if(mail($to_email, $subject, $body, $headers)){
    echo "success";
}
else
    echo "error";
?>
