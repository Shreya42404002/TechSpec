$(document).ready(function(){
  $("#password").keyup(function(){
  	var password=$("#password").val();
  password=password.trim();
 
if(password=="")
{
	setErrorMsg('password_class','Password cannot be blank');
	}else if(7>=password.length)
	{
		setErrorMsg('password_class','Password must be minimum 8 character long');
		}
		else{
		setSuccessMsg('password_class');
}
 
  });
});
