<?php
      session_start();
	  session_id('verification_code_email');
	  $email=$_SESSION['email'];
      $password=md5($_POST['password']);
	  include 'C:\xampp\htdocs\Techspec\Config\Config.php';
	  $query ="UPDATE `registration` SET `pass_word`='$password' WHERE `email`='$email'";
	  mysqli_query($conn,$query);
	  echo mysqli_error($conn);
?>
