$(document).ready(function(){
  $("#cpassword").keyup(function(){
  var cpassword=$("#cpassword").val();
  var password=$("#password").val();
  cpassword=cpassword.trim();
 if(cpassword=="")
{
	setErrorMsg('cpassword_class','Confirm Password cannot be blank');
	}else if((cpassword===password))
	{
		setSuccessMsg('cpassword_class');
		}
		else{
			setErrorMsg('cpassword_class','Confirm Password not Matched');
}

  });
});
