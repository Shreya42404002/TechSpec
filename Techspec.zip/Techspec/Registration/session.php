<?php
      session_start();
      $_SESSION["register_username"]=$_POST['username'];
      $_SESSION["register_email"]= $_POST['email'] ;
      echo "started";  
?>
