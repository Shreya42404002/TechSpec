<?php

      $email=$_POST['email'] ;
      $username=$_POST['username'];
      $password=md5($_POST['password']);
	   $conn=mysqli_connect("localhost","root","","project");
		$query ="INSERT INTO `registration` (`email`, `username`, `pass_word`, `date`, `time`, `status`) VALUES  ('$email', '$username', '$password', CURRENT_DATE(), CURRENT_TIME(),'Not verified')";
		mysqli_query($conn,$query);
		echo mysqli_error($conn);
?>
