const username=document.getElementById('username');
const password=document.getElementById('password');
const email=document.getElementById('email');
const cpassword=document.getElementById('cpassword');
function home() {
         window.location.href="/Techspec/Home/Home.html";  
}
function isEmail(email){
	var atSymbol=email.indexOf("@");
	var dot=email.lastIndexOf('.');
	if(atSymbol<1) {
           return false;
     }else if(dot<(atSymbol+3)) {
           return false;
     }else if(dot== email.length-1) {
          return false;
     }else{
	      return true;
}
}

function insert(email,username,password){
	jQuery.ajax({
		url:"register_to_database.php",
		data:{email:email,username:username, password:password},
		type:"POST",
		success:function(data)
		{
			
		},
		error:function(){
}
}); 

}

function setsession(email,username){
	jQuery.ajax({
		url:"session.php",
		data:{email:email,username:username},
		type:"POST",
		success:function(data)
		{
			
		},
		error:function(){
			
}
}); 
}
function sendEmail(email){
	jQuery.ajax({
		url:"registration_mail.php",
		data:{email:email},
		type:"POST",
		success:function(data)
		{
			
		},
		error:function(){
			
}
}); 
}
function check(){
const username=window.username.value.trim();
const password=window.password.value.trim();
const email=window.email.value.trim();
const cpassword=window.cpassword.value.trim();
 if(email=="")
{
	setErrorMsg('email_class','Email cannot be blank');
}
if(username=="")
{
setErrorMsg('username_class','Username cannot be empty');
}
if(password=="")
{
	setErrorMsg('password_class','Password cannot be blank');
	}
 if(cpassword=="")
{
	setErrorMsg('cpassword_class','Confirm Password cannot be blank');
	}


if(successMsg()==4)
{
	insert(email,username,password);
	setsession(email,username);
	sendEmail(email);
	openPopupSuccess();
	}
}
function setErrorMsg(input,errormsg)
{
	const formControl = document.getElementById(input).className;
	const name="#"+input+"_small";
	const small = document.querySelector(name);
	document.getElementById(input).className="form-control error";
	small.innerText=errormsg;
}
function setSuccessMsg(input)
{
	document.getElementById(input).className="form-control success";
}

function successMsg()
{
		let formCon=document.getElementsByClassName('form-control');
		var count=formCon.length-1;
		var sRate=0;
		for(var i=0;i<formCon.length;i++)
		{
			if(formCon[i].className==="form-control success")
            {
				sRate=sRate+1;
			}
			else {
					
					}
			}
			return sRate;
}
function openPopupSuccess(){
document.getElementById("username").setAttribute("disabled", "disabled");
document.getElementById("email").setAttribute("disabled", "disabled");
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("cpassword").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
disable.classList.add("disabled");
popup_success.classList.add("open-popup-success"); 
}
function openPopupError(){
document.getElementById("username").setAttribute("disabled", "disabled");
document.getElementById("email").setAttribute("disabled", "disabled");
document.getElementById("password").setAttribute("disabled", "disabled");
document.getElementById("cpassword").setAttribute("disabled", "disabled");
document.getElementById("submit").setAttribute("disabled", "disabled");
disable.classList.add("disabled");
popup_error.classList.add("open-popup-error"); 
}
function closePopupError(){
document.getElementById("username").removeAttribute("disabled");
document.getElementById("email").removeAttribute("disabled", "disabled");
document.getElementById("password").removeAttribute("disabled", "disabled");
document.getElementById("cpassword").removeAttribute("disabled", "disabled");
document.getElementById("submit").removeAttribute("disabled", "disabled");
disable.classList.remove("disabled");
popup_error.classList.remove("open-popup-error");
}
