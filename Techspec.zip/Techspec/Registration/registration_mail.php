<?php
$to_email =$_POST['email'];
$Email="techspec.tk@gmail.com";
$subject = "Welcome to the Techspec";
$body = "Welcome to the TechSpec
Thank you for registering and creating an account in the Techspec . With your account, you will be able to track your order history, renew licenses and easily make new purchases. You can login to your account using the username and password you provided when signing up.
You were sent a separate message containing a link to verify your email address. Please verify your address as soon as possible. Failure to do so could result in delayed orders.";
$headers = "From: $Email";
if(mail($to_email, $subject, $body, $headers)){
    echo "success";
}
else
    echo "error";
?>
