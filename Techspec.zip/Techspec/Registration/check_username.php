<?php
	   $conn=mysqli_connect("localhost","root","","project");
		$query ="SELECT * FROM  `registration` WHERE username='" . $_POST['username'] . "' ";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);
		echo $count;
?>
