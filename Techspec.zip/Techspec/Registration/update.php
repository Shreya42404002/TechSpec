<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Register</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" integrity="sha512-PgQMlq+nqFLV4ylk1gwUOgm6CtIIXkKwaIHp/PAIWHzig/lKZSEGKEysh0TCVbHJXCLN7WetD8TFecIky75ZfQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="style.css">
</head>
<style media="screen">

</style>


<body> 
	<button id="cancel" class="cancel" onclick="openPopupError()">Cancel</button>
    <div class="form" id="form">
   <h3>Register Here</h3>



   <?php
	$conn=mysqli_connect("localhost", "root","","project");
	$query = " SELECT * FROM `registration` where username='".$_GET['id']."'";
	$query_run = mysqli_query($conn, $query);
	$sr_no=0;
	if(mysqli_num_rows($query_run) > 0)
        {
        foreach($query_run as $user)
        {

        ?>
 <div class="form-control" id="username_class">
        <label for="username">Username</label>
        <input type="text" value="<?= $user['username']; ?>" placeholder="Username" id="username" name="username">
        <i class="fas fa check-circle"></i> <i class="fas fa-check-circle fa-2x"></i>
         <i class="fas fa exclamation-circle"></i> <i class="fas fa-exclamation-circle fa-2x"></i>
<small id="username_class_small" >Error message</small>
</div>
<div class="form-control" id="email_class">
        <label for="email">Email</label>
        <input type="text" value="<?= $user['email']; ?>" placeholder="Email" id="email" name="email">
        <i class="fas fa check-circle"></i> <i class="fas fa-check-circle fa-2x"></i>
         <i class="fas fa exclamation-circle"></i> <i class="fas fa-exclamation-circle fa-2x"></i>
<small id="email_class_small">Error message</small>
</div>
	
        <div class="form-control">
   <button type="button" id="submit" onclick="check()">UPDATE</button>
   </div>
   <div class="a">
       	</div>
        </div>
    

        <?php }} ?>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="check_username.js"></script>
<script src="check_email.js"></script>
<script src="check_password.js"></script>
<script src="check_cpassword.js"></script>

</body>


       <div class="popup_success" id="popup_success">
            <img src="tick.png">
           <h2>Registration Successfull</h2>
           <button type="button" id="ok" onclick="home()">OK</button>
       </div>
            <div class="popup_error" id="popup_error">
           <h2>Do you really want to cancel registration?</h2>
            <button type="button" id="yes" onclick="home()">Yes</button>
           <button type="button" id="no" onclick="closePopupError()">No</button>
       </div>
  
<script src="execute.js"></script>
</html>
