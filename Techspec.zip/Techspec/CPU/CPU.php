<?php
session_start();
if((isset($_SESSION['admin_username']))||(isset($_SESSION['user_username'])))
{

}

else

{
    header("Location: /Techspec/Login/Login.html");
    exit();
}
?>
<!doctype html>
<html>
  <title>PC</title>
		<body>			
		<div class="box" >
			<h1 align="center" color="red">Webpage You Trying To Access Is Under Maintenance</h1>
		</div>
</body>
</html>